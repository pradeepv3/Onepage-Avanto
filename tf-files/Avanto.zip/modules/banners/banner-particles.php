<div class="banner banner-particles">
	<div id="particles-js" style="position: absolute; left:0;right:0;top:0;bottom:0; width: 100%; height: 100%;"></div>
	<div class="banner-content">
		<h3>Hello...</h3>
		<h2>
			I'M
			<span class="txt-rotate" data-period="1800" data-rotate='["Avanto", "A Web Designer.", "A Developer.", "A Freelancer." ]'></span>
		</h2>
		<p>Never fall in love with an idea. They’re whores. If the one you’re with isn’t doing the job, there’s always, always, always another.</p>
		<a href="#about" class="btn btn-transparent-banner js-scroll-trigger">About Me</a>
	</div>
</div>

<?php $enableParticles = true?>