<div class="banner banner-video">
	<video poster="videos/Traffic_disco.jpg" autoplay playsinline muted loop>
		<source src="videos/Traffic_disco.mp4" type="video/mp4"> HTML video is not supported by your browser.
	</video>
	<div class="banner-content">
		<h3>Hello...</h3>
		<h2>
			I'M
			<span class="txt-rotate" data-period="1800" data-rotate='["Avanto", "A Web Designer.", "A Developer.", "A Freelancer." ]'></span>
		</h2>
		<p>Never fall in love with an idea. They’re whores. If the one you’re with isn’t doing the job, there’s always, always, always another.</p>
		<a href="#about" class="btn btn-transparent-banner js-scroll-trigger">About Me</a>
	</div>
</div>
