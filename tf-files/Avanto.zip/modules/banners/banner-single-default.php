<div class="banner banner-single">
	<div class="banner-content">
		<h3>Hello...</h3>
		<h2>
			I'M A Web Designer.
		</h2>
		<p>Never fall in love with an idea. They’re whores. If the one you’re with isn’t doing the job, there’s always, always, always another.</p>
		<a href="#about" class="btn btn-transparent-banner js-scroll-trigger">About Me</a>
	</div>
</div>
