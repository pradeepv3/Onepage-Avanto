<div class="container">
	<div class="row">
		<div class="col-12 col-lg-8 offset-lg-2  wow zoomIn">
			<h2 class="section-title  br-line">
				Education & Experience
			</h2>
			<p class="text-center">English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is.The European languages are members of the same family.</p>
		</div>

		<div class="col-12 sec-timeline circle-vertical">
			<ul class="timeline">
				<li>
					<div class="timeline-badge wow swing">
						<div class="fa fa-dot-circle-o"></div>
					</div>
					<div class="timeline-panel wow fadeIn ">

						<div class="timeline-content">
							<h6>2000 - 2003</h6>
							<h2>Massachusetts Institute of Technology</h2>
							<p> Integer finibus quam non felis egestas aliquet. Mauris tristique eros pellentesque, eleifend leo non, ornare magna.</p>
						</div>
					</div>
				</li>

				<li class="timeline-invert">
					<div class="timeline-badge wow swing">
						<div class="fa fa-dot-circle-o"></div>
					</div>
					<div class="timeline-panel wow fadeIn">

						<div class="timeline-content">
							<h6>2003 - 2006</h6>
							<h2>Stanford University</h2>
							<p>Cras non diam sed orci ultrices accumsan. Morbi sodales faucibus faucibus. Proin aliquam nunc sit amet bibendum fringilla.</p>
						</div>
					</div>
				</li>

				<li>
					<div class="timeline-badge wow swing">
						<div class="fa fa-dot-circle-o"></div>
					</div>
					<div class="timeline-panel wow fadeIn">

						<div class="timeline-content">
							<h6>2007 - 2010</h6>
							<h2>UX Designer</h2>
							<p>In ullamcorper est a orci suscipit, vel suscipit quam luctus. Pellentesque vel eros vestibulum, bibendum erat vel,
								elementum tortor.</p>
						</div>
					</div>
				</li>

				<li class="timeline-invert">
					<div class="timeline-badge wow swing">
						<div class="fa fa-dot-circle-o"></div>
					</div>
					<div class="timeline-panel wow fadeIn">

						<div class="timeline-content">
							<h6>2011 - Till Date</h6>
							<h2>UI/UX Architect</h2>
							<p>Duis vulputate a tellus ut tempus. Pellentesque laoreet, arcu ut semper vehicula, ex elit malesuada erat, dignissim
								posuere sem urna at nulla.</p>
						</div>
					</div>
				</li>
			</ul>
		</div>

	</div>
</div>
