
<!-- SEO Meta Tags -->
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="Avanto" />

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans%7cJosefin+Sans" rel="stylesheet" type="text/css" />

<!-- Fontawsome Icon-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!-- BootStrap -->
<link href="css/bootstrap-4.1.3.min.css" rel="stylesheet" type="text/css" />

<!-- Animation CSS -->
<link href="css/animations.min.css" rel="stylesheet" type="text/css" />

<!-- Fancy Box CSS-->
<link href="css/jquery.fancybox.min.css" rel="stylesheet" type="text/css" />

<!-- Custom CSS -->
<link href="css/style.css" rel="stylesheet" type="text/css" />

<!-- JQuery Plugin-->
<script src='js/jquery.min.js'></script>
<?php $enableParticles = false;?>