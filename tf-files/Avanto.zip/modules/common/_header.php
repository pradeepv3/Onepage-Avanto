<header class="m-header-wrapper fixed-top">
	<div class="container">
		<div class="navbar navbar-light">
			<a href="index.php" class="navbar-brand">Avanto</a>

			<!-- hamburger menu bar vissible for mobile device -->
			<button type="button" class="navbar-toggler collapsed" data-toggle="collapse" data-target="#navbar">
				<span class="navbar-toggler-icon">&nbsp;</span>
				<span class="navbar-toggler-close" aria-hidden="true">&times;</span>
			</button>
			<!-- Menu Module  -->
			<?php include 'modules/common/_menu.php';?>

		</div>
	</div>
</header>