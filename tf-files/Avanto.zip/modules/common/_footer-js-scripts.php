<!-- JS plugins -->
<script src='js/bootstrap.min.js'></script>
<script src="js/wow.min.js"></script>
<script src="js/jquery.mixitup.min.js"></script>
<script src="js/jquery.fancybox.min.js"></script>

<!-- Custom JS -->
<script src='js/script.js'></script>
<script src='js/type-effect.js'></script>
<?php if ($enableParticles) {?>

<!-- Particles JS -->
<script src="js/particles.min.js"></script>
<script src="js/particles.init.js"></script>
<?php }?>