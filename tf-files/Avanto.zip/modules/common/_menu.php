<nav id="navbar" class="navbar-collapse collapse">
	<ul class="navbar-nav float-md-right">
		<li class="nav-item dropdown brand-nav-link">
			<a class="nav-link js-scroll-trigger d-md-none d-lg-none" href="index.php">Avanto</a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link js-scroll-trigger" href="#home">Home </a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link js-scroll-trigger" href="#about">About </a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link js-scroll-trigger" href="#education">Education </a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link js-scroll-trigger" href="#skils">Skills </a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link js-scroll-trigger" href="#work">Work </a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link js-scroll-trigger" href="#contact">Contact </a>
		</li>
	</ul>
</nav>
