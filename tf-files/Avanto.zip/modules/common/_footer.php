<footer class="sec-footer-wrapper">
	<div class="sec-copyright">
		<div class="container text-center">
			Copyright &copy;
			<?php echo date('Y') ?> | All right Reserved
		</div>
	</div>
</footer>