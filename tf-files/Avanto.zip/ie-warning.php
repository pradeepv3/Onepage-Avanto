<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans|Josefin+Sans" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<title>Update your browser</title>
</head>

<body class="ie-warning">
	<div class="ie-warning_msg">
		<div class="ie-warning_content">
			<h2>Update your browser</h2>
			<p>Your browser is OLD! Upgrade to a different browser or Install Google Chrome to experience this site.</p>
		</div>
	</div>
</body>

</html>
